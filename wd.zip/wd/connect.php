<?php
    $servername="localhost";
    $username="root";
    $password="Teoriakwantowa1";
    $database="wd";
?> 
