<?php
    $servername="localhost";
    $username="your_user";
    $password="your_password";
    $database="database_name";
?> 
